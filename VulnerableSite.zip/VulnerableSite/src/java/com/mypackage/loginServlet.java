/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Devendra
 */
@WebServlet(name = "loginServlet", urlPatterns = {"/loginServlet"})
public class loginServlet extends HttpServlet {

    Connection con;
    ResultSet rs;
    Statement stmt;
    
    public String encrypt(String msg, int shift)
    {
        String s = "";
        for(int i = 0; i < msg.length(); i++)
        {
            char c = (char)(msg.charAt(i) + shift);
            if (c > 'z')
                s += (char)(msg.charAt(i) - (26-shift));
            else
                s += (char)(msg.charAt(i) + shift);
        }
        return s;
    }
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:CISDSN");
            stmt = con.createStatement();
	    
	    String user, pass, encryptedPass;
            
            HttpSession session=request.getSession();  
            
            user = request.getParameter("txtUser");
            pass = request.getParameter("txtPass");
            encryptedPass = this.encrypt(pass, pass.length());
        
            String query = "select * from login where username='" + user + "' and password='" +encryptedPass+ "'";
            rs = stmt.executeQuery(query);
            
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet loginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            if(rs.next())
            {  
                session.setAttribute("username",user);
                session.setAttribute("password",pass);
                response.sendRedirect("InsecureEncryption/Account/Home.html");
            }   
            else
            { 
                out.println("<h1>Wrong ID/Password</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        } 
        catch(SQLException e)
	{
            e.printStackTrace();
                    
	}
	catch(Exception e)
	{
            e.printStackTrace();
	}
        finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
