/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Devendra
 */
@WebServlet(name = "cookieServlet", urlPatterns = {"/cookieServlet"})
public class cookieServlet extends HttpServlet {
Connection con;
    ResultSet rs;
    Statement stmt;
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:CISDSN");
            stmt = con.createStatement();
	    
	    String user, pass;
            user = request.getParameter("txtUser");
            pass = request.getParameter("txtPass");
        
            String query = "select username from logintable where username='" + user + "' and password='" +pass+ "'";
            System.out.println(query);
            rs = stmt.executeQuery(query);
            
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AuthenticationServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            if(rs.next())
            {  
                Cookie name = new Cookie("user",request.getParameter("txtUser"));
                Cookie pwd = new Cookie("pwd",request.getParameter("txtPass"));
                
                name.setMaxAge(5*60);
                pwd.setMaxAge(5*60);
                response.addCookie(name);
                response.addCookie(pwd);
                
                HttpSession session=request.getSession();  
                session.setAttribute("username",user);
                session.setAttribute("password",pass);
                response.sendRedirect("CookieStealing/VerifiedSite/Account/Home.html");
            }   
            else
            { 
                out.println("<h1>Wrong ID/Password</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        } 
        catch(SQLException e)
	{
            out.println(e);
	}
	catch(Exception e)
	{
            out.println(e);
	} finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
