/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Devendra
 */
@WebServlet(name = "TransferServlet", urlPatterns = {"/TransferServlet"})
public class TransferServlet extends HttpServlet {
ResultSet rs, rs2;
Connection con;
Statement stmt;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:CISDSN");
            stmt = con.createStatement();
	    
	    String accno, baccno;
            int amount;
            accno = request.getParameter("txtAccNo");
            amount = Integer.parseInt(request.getParameter("txtAmt"));
            baccno = request.getParameter("txtBAccNo");
        
            String queryPay = "select balance from Transfer where accno=" +accno;
            String queryReceive = "select balance from Transfer where accno=" +baccno;
            System.out.println(queryPay);
            rs = stmt.executeQuery(queryPay);
            
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TransferServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            while(rs.next())
            {
                int balofpayer = rs.getInt("balance");
                System.out.println("Payer's balance: " +balofpayer);
                if(amount <= balofpayer)
                {
                    rs2 = stmt.executeQuery(queryReceive);
                    while(rs2.next())
                    {
                        int balBenefit = rs2.getInt("balance");
                        System.out.println("Receiver's balance: " +balBenefit);
                        int credit = balBenefit + amount;
                        int debit = balofpayer - amount;
                        String query2 = "update Transfer set balance = " +credit+ " where accno =" +baccno;
                        String query3 = "update Transfer set balance = " +debit+ " where accno =" +accno;
                        int i = stmt.executeUpdate(query2);
                        int i2 = stmt.executeUpdate(query3);
                        if(i>0 && i2>0)
                        {
                            out.println("<h1>Money transferred!</h1>");
                        }
                        else
                        {
                            out.println("<h1>Some error occured!</h1>");
                        }
                    }
                }
                else
                {
                    out.println("<h1>Not enough balance in you account!</h1>");
                }
            }
            out.println("</body>");
            out.println("</html>");
        } 
        catch(SQLException e)
	{
            System.err.println(e);
	}
	catch(Exception e)
	{
            System.err.println(e);
	} finally {            
            out.close();
        }
        
    }

}
