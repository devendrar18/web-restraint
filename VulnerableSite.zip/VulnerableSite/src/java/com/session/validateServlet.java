/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.session;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Devendra
 */
@WebServlet(name = "validateServlet", urlPatterns = {"/validateServlet"})
public class validateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String user, pass;
        user = request.getParameter("txtUser");
        pass = request.getParameter("txtPass");
        
        if(user.equals("abcd") && pass.equals("abcd"))
        {
            //creating a session
            HttpSession session = request.getSession();
            String id = session.getId();
            session.setAttribute("user", user);
            response.sendRedirect("SessionManagement/Account/Home.jsp?sessionid=" +id+ "&name=" +user);
        }
        else
        {
            out.println("Wrong ID/Password!");
        }
    }
}
