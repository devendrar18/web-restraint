/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.session;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Devendra
 */
@WebServlet(name = "VerifyServlet", urlPatterns = {"/VerifyServlet"})
public class VerifyServlet extends HttpServlet {
Connection con;
    ResultSet rs;
    Statement stmt;
    
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:CISDSN");
            stmt = con.createStatement();
	    
	    String user, pass;
            user = request.getParameter("txtUser");
            pass = request.getParameter("txtPass");
            String id2 = request.getParameter("sessionid");
            System.out.println( "id2: "+id2);
        
            String query = "select username from logintable where username='" + user + "' and password='" +pass+ "'";
            System.out.println(query);
            rs = stmt.executeQuery(query);
            
            if(rs.next())
            {  
                HttpSession session = request.getSession();
                session.setAttribute("user",user);
                if(id2.equals("null") || id2.equals(""))
                {
                    double id = Math.random();
                    response.sendRedirect("SessionHijacking/home.jsp?sessionid=" +id);
                }
                else
                {
                    response.sendRedirect("SessionHijacking/home.jsp?sessionid=" +id2);
                }
            }   
            else
            { 
                out.println("<h1>Wrong ID/Password</h1>");
            }
        } 
        catch(SQLException e)
	{
            out.println(e);
	}
	catch(Exception e)
	{
            out.println(e);
	} finally {            
            out.close();
        }
    }

    
}
