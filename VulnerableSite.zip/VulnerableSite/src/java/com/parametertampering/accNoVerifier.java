/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parametertampering;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Devendra
 */
@WebServlet(name = "accNoVerifier", urlPatterns = {"/accNoVerifier"})
public class accNoVerifier extends HttpServlet {
Connection con;
Statement stmt;
ResultSet rs;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accNo = request.getParameter("txtAccNo");
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:CISDSN");
            stmt = con.createStatement();
            rs = stmt.executeQuery("select * from tblTrans where accno=" +accNo);
                        
            if(rs.next())
            {
                response.sendRedirect("statementServlet?accNo=" +accNo);
            }
            else
            {
                response.sendRedirect("ParameterTampering/index.html");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
