package com.parametertampering;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mypackage.DatabaseConnector;

/**
 * Servlet implementation class AccNoVerifier
 */
@WebServlet("/AccNoVerifier")
public class AccNoVerifier extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String accno = request.getParameter("txtAccNo");
		String query = "select * from tblTrans where accno=?;";
		PreparedStatement psmt = DatabaseConnector.getPreparedStatement(query);
		
		try
		{
			out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet statementServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<b>The statement for Account No. " +accno+ " :</b>");
			psmt.setInt(1, Integer.parseInt(accno));
			ResultSet rs = psmt.executeQuery();
			out.println("<table border='1' align='center' width='60%' >");
            out.println("<tr><th>Transaction No.</th><th>Transaction</th><th>Amount</th><th>Credit / Debit</th></tr>");
            
            while(rs.next())
            {
                out.println("<tr><td>"+ rs.getInt(1) +"</td>");
                out.println("<td>"+ rs.getString(2) +"</td>");
                out.println("<td>"+ rs.getInt(3) +"</td>");
                out.println("<td>"+ rs.getString(4) +"</td></tr>");
            }
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
		}
		catch(SQLException e)
		{
			System.err.println(e);
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
	}

}
