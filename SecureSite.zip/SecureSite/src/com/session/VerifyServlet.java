package com.session;

import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mypackage.DatabaseConnector;

/**
 * Servlet implementation class VerifyServlet
 */
@WebServlet("/VerifyServlet")
public class VerifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String user, pass, userid, pwd;
		user = request.getParameter("txtUser");
		pass = request.getParameter("txtPass");
		
		HttpSession session = request.getSession();
		session.invalidate();
		
		String query = "select * from logintable where username=? and password=?;";
		PreparedStatement psmt = DatabaseConnector.getPreparedStatement(query);
		
		try
		{
			psmt.setString(1, user);
			psmt.setString(2, pass);
			ResultSet rs = psmt.executeQuery();
			
			if(rs.next())
			{
				userid = rs.getString("username");
				pwd = rs.getString("password");
				if(userid.equals(user) && pwd.equals(pass))
				{
					session = request.getSession();
					String id = session.getId();
	                session.setAttribute("user",user);
	                response.sendRedirect("SessionHijacking/Home.jsp?sid=" +id);
				}
				else
				{
					out.println("<h2>Wrong ID/password!");
				}
			}
		}
		catch(SQLException e)
		{
			System.err.println(e);
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
	}

}
