package com.mypackage;

import java.io.*;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;

/**
 * Servlet implementation class TransferServlet
 */
@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String accno, baccno, token;
        int amount;
        accno = request.getParameter("txtAccNo");
        amount = Integer.parseInt(request.getParameter("txtAmt"));
        baccno = request.getParameter("txtBAccNo");
        token = request.getParameter("token");
        
        HttpSession session = request.getSession();
        System.out.println("csrfToken : " +session.getAttribute("csrfToken"));
        
        if(token.equals(session.getAttribute("csrfToken").toString()))
        {
        	String ip = null;
        	InetAddress localIp = null;
    		try
    		{
    			URL whatismyip = new URL("http://bot.whatismyipaddress.com");
    			localIp = InetAddress.getLocalHost();
    			BufferedReader in = new BufferedReader(new InputStreamReader(whatismyip.openStream()));
    			ip = in.readLine(); //you get the IP as a String
    		}
    		catch(UnknownHostException e)
    		{
    			ip = localIp.toString();
    		}
    		catch(Exception e)
    		{
    			System.out.println(e);
    		}
    		
        	String queryPay, queryReceive, queryLog;
            queryPay = "select balance from Transfer where accno=" +accno;
            queryReceive = "select balance from Transfer where accno=" +baccno;
            queryLog = "insert into tblLog values(" +accno+ ", " +baccno+ ", " +amount+ ", getdate(), '" +ip+ "');";
            
            try
            {
            	Statement stmt = DatabaseConnector.getStatement();
            	System.out.println(queryPay);
            	
            	ResultSet rs = stmt.executeQuery(queryPay);
            	
            	while(rs.next())
            	{
            		int balOfPayer = rs.getInt("balance");
            		System.out.println("Payer's balance: " +balOfPayer);
            		if(amount <= balOfPayer)
                    {
            			ResultSet rs2 = stmt.executeQuery(queryReceive);
                        while(rs2.next())
                        {
                            int balOfReceiver = rs2.getInt("balance");
                            System.out.println("Receiver's balance: " +balOfReceiver);
                            int credit = balOfReceiver + amount;
                            int debit = balOfPayer - amount;
                            String query2 = "update Transfer set balance = " +credit+ " where accno =" +baccno;
                            String query3 = "update Transfer set balance = " +debit+ " where accno =" +accno;
                            int i = stmt.executeUpdate(query2);
                            int i2 = stmt.executeUpdate(query3);
                            int i3 = stmt.executeUpdate(queryLog);
                            if(i>0 && i2>0)
                            {
                                out.println("<h1>Money transferred!</h1>");
                            }
                            else
                            {
                                out.println("<h1>Some error occured!</h1>");
                            }
                        }
                    }
                    else
                    {
                        out.println("<h1>Not enough balance in you account!</h1>");
                    }
            	}
            	
            }
            catch(SQLException e)
            {
            	System.out.println(e);
            }
            catch(Exception e)
            {
            	System.out.println(e);
            }
        }
        else
        {
        	out.println("<h1>Unexpected error occured!</h1>");
        }
	}
}
