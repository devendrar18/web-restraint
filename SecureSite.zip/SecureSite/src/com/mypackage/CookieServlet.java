package com.mypackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

/**
 * Servlet implementation class CookieServlet
 */
@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	PrintWriter out = response.getWriter();
    	String user = request.getParameter("txtUser");
    	String pass = request.getParameter("txtPass");
    	
    	try
    	{
    		String query = "select * from logintable where username=? and password=?;";
    		PreparedStatement psmt = DatabaseConnector.getPreparedStatement(query);
    		psmt.setString(1, user);
    		psmt.setString(2, pass);
    		
    		ResultSet rs = psmt.executeQuery();
    		if(rs.next())
    		{
    			String userid, pwd;
    			userid = rs.getString("username");
    			pwd = rs.getString("password");
    			
    			if(user.equals(userid) && pass.equals(pwd))
    			{
    				byte[] salt = SHAExample.getSalt();
    				String hashedData = SHAExample.get_SHA_512_SecurePassword(user, salt);
    				System.out.println(hashedData);
    				
    				Cookie name = new Cookie("user",hashedData);
    				name.setMaxAge(5*60);
                    response.addCookie(name);
                    
    				HttpSession session=request.getSession();  
                    session.setAttribute("user",user);
                    response.sendRedirect("CookieStealing/VerifiedSite/Account/Home.jsp");
    			}
    			else
    			{
    				out.println("Wrong ID/Password");
    				
    			}
    		}
    		else
    		{
    			out.println("Wrong ID/Password");
    		}
    	}
    	catch(SQLException e)
    	{
    		System.err.println(e);
    	}
    	catch(Exception e)
    	{
    		System.err.println(e);
    	}
	}

}
