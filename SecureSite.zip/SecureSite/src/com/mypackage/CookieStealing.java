package com.mypackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieStealing
 */
@WebServlet("/CookieStealing")
public class CookieStealing extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		try
		{
			out.print("<h2>");
			Cookie cookie = null;
	        Cookie[] cookies = null;
	        // Get an array of Cookies associated with this domain
	        cookies = request.getCookies();
	        if( cookies != null )
	        {
	            out.println("Found Cookies Name and Value</h2>");
	            for (int i = 0; i < cookies.length; i++)
	            {
	                cookie = cookies[i];
	                out.print("Name : " + cookie.getName() + ",  ");
	                out.print("Value: " + cookie.getValue()+" <br/>");
	            }     
	        }
	        else
	        {
	            out.println("<h2>No cookies found</h2>");
	        }
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
	}

}
