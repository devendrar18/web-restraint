package com.mypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnector2
{
	public static Connection con;
	public static String url="jdbc:mysql://localhost:3306/cis";
	public static String username="root";
	public static String password="root";
	
	/*-------Starting of Connection Method--------*/
	
	public static Connection getConnection()
	{
		try
		{
	        Class.forName("com.mysql.jdbc.Driver");
	        con = DriverManager.getConnection(url,username,password);
	    }
	    catch(SQLException e)
	    {
	    	e.printStackTrace();
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	       return con;
	}
	
	/*----------Starting of Statement getStatement()----------*/
	
    public static Statement getStatement()
    {
        Statement stmt=null;
       try
       {
            con=getConnection();
            stmt=con.createStatement();
       }
       catch(SQLException se)
       {
           se.printStackTrace();
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
       return stmt;  
    }
    
    /*---------Starting of Prepared Statement--------*/
    
    public static PreparedStatement getPreparedStatement(String query)
    {
        PreparedStatement pstmt=null;
       try
       {
            con=getConnection();
            pstmt=con.prepareStatement(query);
       }
       catch(SQLException se)
       {
           se.printStackTrace();
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
       return pstmt;  
    }
    
    /*----------Starting of Result set-------*/
    
    public static ResultSet getResultSet(String query)
    {
        ResultSet rs=null;
        try
        {
            Statement stmt=getStatement();
            rs=stmt.executeQuery(query);
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
    
    /*------------Close---------------*/
    
    public static void Close()
    {
        try
        {
            if(con!=null)
            {
                con.close();
            }
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
	public static void closeConnection()
	{
	   try
       {
		   if(con!=null)
		   {
			   con.close();
           }  
       }
	   catch(Exception e)
	   {
		   e.printStackTrace();
       }
    }
}
