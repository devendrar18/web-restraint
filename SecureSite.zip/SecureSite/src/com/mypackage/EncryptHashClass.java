package com.mypackage;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;

public class EncryptHashClass 
{
	public static SecretKey getSecretEncryptionKey() throws Exception
	{
	    KeyGenerator generator = KeyGenerator.getInstance("AES");
	    generator.init(128); // The AES key size in number of bits
	    SecretKey secKey = generator.generateKey();
	    return secKey;
	}
	
	public static byte[] encryptText(String plainText,SecretKey secKey) throws Exception
	{
		// AES defaults to AES/ECB/PKCS5Padding in Java 7
	    Cipher aesCipher = Cipher.getInstance("AES");
	    aesCipher.init(Cipher.ENCRYPT_MODE, secKey);
	    byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
	    return byteCipherText;
	}

	public static String decryptText(byte[] byteCipherText, SecretKey secKey) throws Exception 
	{
	    // AES defaults to AES/ECB/PKCS5Padding in Java 7
	    Cipher aesCipher = Cipher.getInstance("AES");
	    aesCipher.init(Cipher.DECRYPT_MODE, secKey);
	    byte[] bytePlainText = aesCipher.doFinal(byteCipherText);
	    return new String(bytePlainText);
	}
	     
	public static String  bytesToHex(byte[] hash) 
	{
	    return DatatypeConverter.printHexBinary(hash);
	}
/**************************************************************************************************/
	public static String getHash(String dataToHash, byte[] salt)
    {
    	String generatedHash = null;
        try 
        {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(salt);
            byte[] bytes = md.digest(dataToHash.getBytes());
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedHash = sb.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        return generatedHash;
    }
     
    //Add salt
    public static byte[] getSalt() throws NoSuchAlgorithmException
    {
        
        byte[] salt = new byte[]{1,1,1,1,1,0,0,0,0,0};
        return salt;
    }
    
	public static void main(String[] args) throws Exception 
	{
		String plainText = "Hello World";
		SecretKey secKey = getSecretEncryptionKey();
		byte[] cipherText = encryptText(plainText, secKey);
		String aesCipher = bytesToHex(cipherText);
		String aesKey = bytesToHex(secKey.getEncoded());
		byte[] salt = getSalt();
        
        String hashedValue = getHash(aesCipher, salt);
        
		String decryptedText = decryptText(cipherText, secKey);
		
		System.out.println("Original Text:" + plainText);
		System.out.println("AES Key (Hex Form):"+ aesKey);
		System.out.println("Encrypted Text (Hex Form):"+ aesCipher);
		System.out.println("Encrypted + Hashed text:" + hashedValue);
		
		System.out.println("Decrypted Text:"+ decryptedText);
	}
	

}
